---
name: Momentum Merger
version: 1.0.0
cmc_requirements:
  indicators: ["RSI","MACD","FearGreed"]
  data_frequency: daily
  min_history_days: 90
risk_profile: moderate
backtest_performance:
  sharpe: 0
  max_drawdown: 0%
  total_return: 0%
strategy_key: 0xdbb80a9392655d562a608adff9b7f5d3a47a4ac180c0784a77fee7352b578078
digest: 0x717f6988e31cb041230aac418ae56f1ff8619460b74651a4849736748e4fa08f
simulation_only: true
live_trading: false
data_source: CoinMarketCap Data API
---

# Momentum Merger

Track 2 CMC Strategy Skill — backtestable spec only (no live execution).

## Fingerprint
- strategyKey: `0xdbb80a9392655d562a608adff9b7f5d3a47a4ac180c0784a77fee7352b578078`
- digest: `0x717f6988e31cb041230aac418ae56f1ff8619460b74651a4849736748e4fa08f`

## Rules
- Entry: RSI(14) < 30 AND MACD bullish crossover AND CMC Fear & Greed < 25 (Extreme Fear).
- Exit: RSI(14) > 70 OR MACD bearish crossover.
- Position sizing: 100% capital on signal, full exit on opposite signal.
- Simulation only — no live trading (Track 2).
